 <?php
  include("../MasterPages/WarehouseHeader.php");
  ?>
  
  <h1>Welcome for Warehouse Login</h1>
  
  <ul>
  <li>Registered Warehouse can view user bookings.</li>
  <li>He can change the password.</li>
  <li>He can view the registered information.</li>
  </ul>
  
  
   <?php
  include("../MasterPages/Footer.php");
  ?>
  