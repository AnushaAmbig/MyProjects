<?php
session_start();
$Mobile=$_SESSION['UserID'];

include_once "../DB/db.php";
?>

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

	$sql = "SELECT * FROM tblwarehouse where Mobile='$Mobile'";
	$result=execute($sql);	
	
	if($row = $result->fetch_assoc())
 	{
 		$ID=$row['ID'];
		$WarehouseName=$row['WarehouseName'];
		$Category=$row['Category'];
		$AddressLine1=$row['AddressLine1'];
		$AddressLine2=$row['AddressLine2'];
		$City=$row['City'];
		$Mobile=$row['Mobile'];
		$BuiltUpArea=$row['BuiltUpArea'];
		$Capacity=$row['Capacity'];
		$AboutWarehouse=$row['AboutWarehouse'];
	}
?>


<?php


if (isset($_POST['btnupdate']))
{
	$AddressLine1=$_POST['txtAddressLine1'];
	$AddressLine2=$_POST['txtAddressLine2'];
	$BuiltUpArea=$_POST['txtBuiltUpArea'];
	$Capacity=$_POST['txtCapacity'];
	$AboutWarehouse=$_POST['txtAboutWarehouse'];
			
	 $sql="UPDATE `tblwarehouse` SET `AddressLine1`='$AddressLine1',`AddressLine2`='$AddressLine2',`BuiltUpArea`='$BuiltUpArea',`Capacity`='$Capacity',`AboutWarehouse`='$AboutWarehouse' WHERE Mobile='$Mobile'";
	    	
	$res=execute($sql);	
		
	if($res)
	{
	
		echo "<script type='text/javascript'> alert('Updated Successfully');</script>";
		echo "<meta http-equiv='refresh' content='0;url=WarehouseInfo.php'>";
	}
	else
	{
		echo "<script type='text/javascript'> alert('Action not processed');</script>";
	}
}
	
?>



  <?php
  include("../MasterPages/WarehouseHeader.php");
  ?>
  
  <h1>Warehouse Details Page</h1>
  
            
<form id="frminfo" name="frminfo" method="post" action="" enctype="multipart/form-data">
           	<table id="minitable">
            	<tr>
                	<td style="width:50%;">ID </td>
                    <td><?php echo $ID; ?></td>
                </tr>
       			
					
				<tr>
                	<td>Warehouse Name</td>
                    <td><?php echo $WarehouseName; ?></td>
                </tr>
				
				
				<tr>
                	<td>Category</td>
                    <td><?php echo $Category; ?></td>
                </tr>
				
				<tr>
                	<td>Address Line1 </td>
                    <td><label id="l3"><?php echo $AddressLine1; ?></label>
					 <input type="text" name="txtAddressLine1" maxlength="100" class="hide" value="<?php echo $AddressLine1; ?>"/>
					</td>
                </tr>
				
                	
				<tr>
                	<td>Address Line2 </td>
                    <td><label id="l4"><?php echo $AddressLine2; ?></label>
					 <input type="text" name="txtAddressLine2" maxlength="100" class="hide" value="<?php echo $AddressLine2; ?>"/>
					</td>
                </tr>
				
				 <tr>
                	<td>City</td>
					<td><?php echo $City; ?></td>
                </tr>
				
				<tr>
                	<td>Mobile</td>
					<td><?php echo $Mobile; ?></td>
                </tr>
				
				<tr>
                	<td>Built Up Area</td>
					<td><label id="l6"><?php echo $BuiltUpArea; ?></label>
					<input type="text" name="txtBuiltUpArea" maxlength="100" class="hide" value="<?php echo $BuiltUpArea; ?>"/></td>
                </tr>
				
				<tr>
                	<td>Capacity</td>
					<td>
					<label id="l7"><?php echo $Capacity; ?></label>
					<input type="text" name="txtCapacity" maxlength="100" class="hide" value="<?php echo $Capacity; ?>"/></td>
                </tr>
				
				<tr>
                	<td>About Warehouse</td>
					<td>
					<label id="l8"><?php echo $AboutWarehouse; ?></label>
					<textarea name="txtAboutWarehouse" style="height:100px;" class="hide"><?php echo $AboutWarehouse; ?></textarea></td>
                </tr>
				
               <tr>
                	  <td>
                      
                 <Input type="submit" class="hide" name="btnupdate" value="Update" onclick="return check(frminfo)" id="button"/></td>
                 <td>
               <button type="button" name="btnedit" onclick="addInput(this.form);" id="button">Edit</button>
              
               <button type="button" class="hide" name="btncancel" onclick="reloadPage()" id="button" >Cancel</button>
                </td>
                </tr>
                   
			
			
           </table>
           </form>
         
  
  
    <?php
  include("../MasterPages/Footer.php");
  ?>
  
  <style type="text/css">
input {display:block;}
.hide {display:none;} 

textarea {display:block;}
</style>


 <script language="javascript">
function check(f)
{
if (f.txtAddressLine1.value.trim()=="")
{
alert("This AddressLine1 field can not be empty");
f.txtAddressLine1.focus();
return false ;
}
else if (f.txtBuiltUpArea.value.trim()=="")
{
alert("This Built Up area field can not be empty");
f.txtBuiltUpArea.focus();
return false ;
}
else if (f.txtCapacity.value.trim()=="")
{
alert("This Capacity field can not be empty");
f.txtCapacity.focus();
return false ;
}
else
return true;
}

</script>
