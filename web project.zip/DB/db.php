<?php 

function execute($sql)
{
$con=mysqli_connect('localhost','root','','warehouse');

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
} 

//$res=mysqli_query($con,$sql);


$res = $con->query($sql);

/* close connection */
$con->close();

return $res;
}

?>