<?php
  include("MasterPages/Header.php");
  ?>
  
  <h1>Agricultural Warehouse Portal</h1>
  
  
  <p>
Agricultural Warehouse Portal is focused on empowering farmers both small and large - so that they gain more from their harvests.We help farming communities protect their produce and reduce post harvest losses to increase food availability without placing additional burden on the environment. As agriculture moves up the global growth agenda, we are addressing one of the planets most pressing challenges today - food security with depleting resources.
</p>
<p>We help farmers to contact the warehouses easily. Farmers can select the warehouse and storage types based on the requirement of their products. They can book the slot for required period of time. No need of visiting every warehouse instead of that a farmer can select the warehouse and storage system with one click.
</p>
<p>
Here,warehouse owners update their information and availability of place in the warehouse. They view the bookings of the farmers and proceed their order.
</p>
<p>
Since this work is fast and effective, farmers can easily contact the warehouse and store their products. This helps in reducing the post harvest loss. Through this we are trying to bring a smile on every farmers face. 
  </p>
  
  <?php
  include("MasterPages/Footer.php");
  ?>
  