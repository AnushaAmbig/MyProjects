  
    
  <?php
include_once "../DB/db.php";

if(isset($_GET['Mode'] ))
{
	if($_GET['Mode'] =="Delete") 
	{
		$sqldel="Delete from tblcity where ID='".$_REQUEST['ID']."' ";
		$ress=execute($sqldel);	
	
		if($ress)
		{
			echo "<script type='text/javascript'> alert('Deleted Successfully');</script>";
			echo "<meta http-equiv='refresh' content='0;url=AdminCityList.php'>";
		}
		else
		{
			echo "<script type='text/javascript'> alert('Action not processed');</script>";
		}
	}
}

?>


  <?php
  include("../MasterPages/AdminHeader.php");
  ?>
  
   <h1>Bank List</h1>
 
   <button type="button" name="btnadd" class="button" onClick="window.location.href='AdminCityAdd.php'">Add New</button>
   <br>
 <?php
	
	$sql = "SELECT * FROM tblcity";
			  
	$result=execute($sql);	
	if ($result->num_rows > 0) 
	{
?>

	<table id="minitable">
     
     <tr>
	 <th style="width:65%;">City</th>
     <th>Delete</th>
     </tr>
     
     <?php
while($row = $result->fetch_assoc()) 
  { ?>
     <tr>

	 <td> <?php echo $row['City']; ?></td>
   <td><a href="AdminCityList.php?ID=<?php echo $row['ID']; ?>&Mode=Delete" onClick="return confirm(' Are You Sure To Delete? ');" >
  Delete</a>	 </td>
	</tr>
<?php
  }
?>
   </table>
   <?php
	}
	else
	{
	   echo "No Records Found";
	}
 
  ?>
  
       <?php
include("../MasterPages/Footer.php");
  ?>