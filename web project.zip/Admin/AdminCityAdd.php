  <?php
  include("../MasterPages/AdminHeader.php");
  ?>
  
  
  
   <h1> Add City</h1>
 
 <form id="frmadd" name="frmadd" method="post" action="">
           	<table id="minitable">
            	<tr>
                	<td>City</td>
					<td><input type="text" name="txtCity" maxlength="100"/></td>
                </tr>
       		
                <tr>
                	<td colspan="2" style="text-align:center;">
                    <input type="submit" name="btnsave" onClick="return check(frmadd)" value="Add New">
                    <button type="button" name="btncancel" onClick="window.location.href='AdminCityList.php'">Cancel</button>
   	
                    </td>
                </tr>
           </table>
           </form>
  
  
  
       <?php
  include("../MasterPages/Footer.php");
  ?>
  
  
   <?php
if(isset($_REQUEST['btnsave']))
{

include_once "../DB/db.php";

$sql="INSERT INTO `tblcity`(`City`) VALUES 
					  ('".$_REQUEST['txtCity']."')";

$result=execute($sql);	
	if($result)
	{
		echo "<script type='text/javascript'> alert('Saved Successfully');</script>";
		echo "<meta http-equiv='refresh' content='0;url=AdminCityList.php'>";
	}
	else
	{
		echo "<script type='text/javascript'> alert('Action not processed');</script>";
	}
	
}
?>



<script language="javascript">
function check(f)
{
  if(f.txtCity.value=="")
   {
        alert("City Name cannot be empty");
        f.txtCity.focus();
		return false ;
    }
	else
		return true;

}
</script>
