 <?php
  include("../MasterPages/AdminHeader.php");
  ?>
  
  <h1>Welcome for Admin Login</h1>
  
  <ul>
  <li>Admin is super user of our application.</li>
  <li>Admin is maintain the list of categories and cities.</li>
  <li>Admin view the list of Warehouses.</li>
  </ul>
  
  
   <?php
  include("../MasterPages/Footer.php");
  ?>
  