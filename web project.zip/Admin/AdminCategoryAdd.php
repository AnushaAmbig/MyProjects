  <?php
  include("../MasterPages/AdminHeader.php");
  ?>
  
  
  
   <h1> Add Warehouse Categories</h1>
 
 <form id="frmadd" name="frmadd" method="post" action="">
           	<table id="minitable">
            	<tr>
                	<td>Category</td>
					<td><input type="text" name="txtCategory" maxlength="100"/></td>
                </tr>
       		
                <tr>
                	<td colspan="2" style="text-align:center;">
                    <input type="submit" name="btnsave" onClick="return check(frmadd)" value="Add New">
                    <button type="button" name="btncancel" onClick="window.location.href='AdminCategoryList.php'">Cancel</button>
   	
                    </td>
                </tr>
           </table>
           </form>
  
  
  
       <?php
  include("../MasterPages/Footer.php");
  ?>
  
  
   <?php
if(isset($_REQUEST['btnsave']))
{

include_once "../DB/db.php";

$sql="INSERT INTO `tblcategory`(`Category`) VALUES 
					  ('".$_REQUEST['txtCategory']."')";

$result=execute($sql);	
	if($result)
	{
		echo "<script type='text/javascript'> alert('Saved Successfully');</script>";
		echo "<meta http-equiv='refresh' content='0;url=AdminCategoryList.php'>";
	}
	else
	{
		echo "<script type='text/javascript'> alert('Action not processed');</script>";
	}
	
}
?>



<script language="javascript">
function check(f)
{
  if(f.txtCity.value=="")
   {
        alert("City Name cannot be empty");
        f.txtCity.focus();
		return false ;
    }
	else
		return true;

}
</script>
