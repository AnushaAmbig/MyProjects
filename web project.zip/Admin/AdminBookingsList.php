
<?php
   
   include_once "../DB/db.php";

  include("../MasterPages/AdminHeader.php");
  ?>
  
  
 <h1>Booking List</h1>


 <form id="frmlist" name="frmlist" method="post" action="">
        	
            <table id="logintable">
            <tr>
            <td>Status</td>
            <td>
    			 <select name="cmbStatus"  class="select" onChange="check1()">
        		    <option value="0">Select</option>
      				<?php
						 $sql = "SELECT DISTINCT(Status) FROM tblbookings";
						$res=execute($sql);	
						
					   	while($result = $res->fetch_assoc())
        				{
	  			      ?>
				            <option <?php echo (isset($_REQUEST['cmbStatus']) ? (($_REQUEST['cmbStatus']== $result['Status']) ? "Selected" : "") : "")  ?> value = "<?php echo $result['Status']?>"><?php echo $result['Status'] ?></option>                           
        				<?php
							}
						?>
                        </select>
                        </td>
            </tr>
            </table>
            </form>
			
			
 
  <?php
  if(isset($_REQUEST['cmbStatus']))
	{
		if($_REQUEST['cmbStatus']!='0')
		{
			$Status=$_REQUEST['cmbStatus'];
			
			$sql = "SELECT b.ID,f.FormerName,b.BookedDate,b.Status,w.WarehouseName FROM tblbookings b,tblformers f,tblwarehouse w where f.Mobile=b.BookedBy and b.Status='$Status' and b.BookedWarehouse=w.Mobile";
	
			$result=execute($sql);	
	
			if ($result->num_rows > 0) 
			{

?>



	 <table id="fulltable">
     
     <tr>
	 <th>Farmer Name</th>
	 <th>Warehouse</th>
     <th>Booked Date</th>
	 <th>Status</th>
      <th>View</th>
     </tr>
     
     <?php
while($row = $result->fetch_assoc()) 
  { ?>
     <tr>
      <td> <?php echo $row['FormerName']; ?></td>
	  <td> <?php echo $row['WarehouseName']; ?></td>
	  <td> <?php $BookedDate=date('d-m-Y', strtotime($row['BookedDate'])); echo $BookedDate; ?></td>
      <td> <?php echo $row['Status']; ?></td>
   <td><a href="AdminBookingsView.php?ID=<?php echo $row['ID']; ?>">View</a></td>
	</tr>
<?php
  }
?>
   </table>
   
  
    <?php
	}
	else
	{
	   echo "No Records Found";
	}
	
	}
}

  include("../MasterPages/Footer.php");
  ?>
  

  <script type="text/javascript">
function check1() {
     document.frmlist.submit()
}
</script>