  
    
  <?php
include_once "../DB/db.php";

if(isset($_GET['Mode'] ))
{
	if($_GET['Mode'] =="Delete") 
	{
		$sqldel="Delete from tblcategory where ID='".$_REQUEST['ID']."' ";
		$ress=execute($sqldel);	
	
		if($ress)
		{
			echo "<script type='text/javascript'> alert('Deleted Successfully');</script>";
			echo "<meta http-equiv='refresh' content='0;url=AdminCategoryList.php'>";
		}
		else
		{
			echo "<script type='text/javascript'> alert('Action not processed');</script>";
		}
	}
}

?>


  <?php
  include("../MasterPages/AdminHeader.php");
  ?>
  
   <h1>Warehouse Category List</h1>
 
   <button type="button" name="btnadd" class="button" onClick="window.location.href='AdminCategoryAdd.php'">Add New</button>
   <br>
 <?php
	
	$sql = "SELECT * FROM tblcategory";
			  
	$result=execute($sql);	
	if ($result->num_rows > 0) 
	{
?>

	<table id="minitable">
     
     <tr>
	 <th style="width:65%;">Category</th>
     <th>Delete</th>
     </tr>
     
     <?php
while($row = $result->fetch_assoc()) 
  { ?>
     <tr>

	 <td> <?php echo $row['Category']; ?></td>
   <td><a href="AdminCategoryList.php?ID=<?php echo $row['ID']; ?>&Mode=Delete" onClick="return confirm(' Are You Sure To Delete? ');" >
  Delete</a>	 </td>
	</tr>
<?php
  }
?>
   </table>
   <?php
	}
	else
	{
	   echo "No Records Found";
	}
 
  ?>
  
       <?php
include("../MasterPages/Footer.php");
  ?>