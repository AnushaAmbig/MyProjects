<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include_once "../DB/db.php";

$ID=$_REQUEST['ID'];

	$sql = "SELECT * FROM tblwarehouse where ID=$ID";
	
	$result=execute($sql);	
	
	if($row = $result->fetch_assoc())
 	{
 		$ID=$row['ID'];
		$WarehouseName=$row['WarehouseName'];
		$Category=$row['Category'];
		$AddressLine1=$row['AddressLine1'];
		$AddressLine2=$row['AddressLine2'];
		$City=$row['City'];
		$Mobile=$row['Mobile'];
		$BuiltUpArea=$row['BuiltUpArea'];
		$Capacity=$row['Capacity'];
		$AboutWarehouse=$row['AboutWarehouse'];
		$Status=$row['Status'];
	}
?>

<?php


		if (isset($_POST['btnDelete']))
		{
			 $sql="DELETE FROM tblwarehouse where ID=$ID";
			 $result=execute($sql);	
			 
			 
			 if($result)
			 {
				if($Status=='Accepted')
				{
				 	$sql="DELETE FROM tbllogin where UserID='$Mobile'";
				 	$res=execute($sql);	
				}

			 	echo "<script type='text/javascript'> alert('Deleted Successfully');</script>";
			 	echo "<meta http-equiv='refresh' content='0;url=AdminWarehouseList.php'>";
			 }
			 else
			 {
				 echo "<script type='text/javascript'> alert('Action Not Processed');</script>";
			 	 echo "<meta http-equiv='refresh' content='0;url=AdminWarehouseList.php'>";
			 }
		}
		
		
		
		if (isset($_POST['btnAccept']))
		{
			 $sql="UPDATE tblwarehouse set Status='Accepted' where ID=$ID";
			 $result=execute($sql);	
			 
			 
			 if($result)
			 {
				$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    				$pwd = substr(str_shuffle( $chars ), 0, 5);
			
				$mobileno=$Mobile;
				//$str="Dear User, Your have registered successfully. Your User ID is ".$Mobile." and Password is ".$pwd;
		
				$sql="INSERT INTO `tbllogin`(`UserID`, `Password`, `UserType`) VALUES ('$Mobile','$pwd','Warehouse')";
				$res=execute($sql);	
			 	//echo "<script type='text/javascript'> alert('Registration Accepted Successfully');</script>";
				//echo "<script type='text/javascript'> alert('$str');</script>";
			 	echo "<meta http-equiv='refresh' content='0;url=AdminWarehouseList.php'>";
			 }
			 else
			 {
				 echo "<script type='text/javascript'> alert('Action Not Processed');</script>";
			 	 echo "<meta http-equiv='refresh' content='0;url=AdminWarehouseList.php'>";
			 }
		}
		
?>


  <?php
  include("../MasterPages/AdminHeader.php");
  ?>
  
  <h1>Warehouse Details Page</h1>
  
            
<form id="frmUsers" name="frmUsers" method="post" action="" enctype="multipart/form-data">
           	<table id="minitable">
            	<tr>
                	<td style="width:50%;">ID </td>
                    <td><?php echo $ID; ?></td>
                </tr>
       			
					
				<tr>
                	<td>Warehouse Name</td>
                    <td><?php echo $WarehouseName; ?></td>
                </tr>
				
				<tr>
                	<td>Category</td>
                    <td><?php echo $Category; ?></td>
                </tr>
				
				<tr>
                	<td>Address Line1 </td>
                    <td><?php echo $AddressLine1; ?></td>
                </tr>
				
                	
				<tr>
                	<td>Address Line2 </td>
                    <td><?php echo $AddressLine2; ?></td>
                </tr>
				
				 <tr>
                	<td>City</td>
					<td><?php echo $City; ?></td>
                </tr>
				
				
				  <tr>
                	<td>Mobile</td>
					<td><?php echo $Mobile; ?></td>
                </tr>
				
				 <tr>
                	<td>BuiltUp Area</td>
                    <td><?php echo $BuiltUpArea; ?></td>
                </tr>
				
				<tr>
                	<td>Capacity</td>
                    <td><?php echo $Capacity; ?></td>
                </tr>
				
				<tr>
                	<td>About Warehouse</td>
                    <td><?php echo $AboutWarehouse; ?></td>
                </tr>
				
				<tr>
                	<td>Status</td>
					<td><label id="l1"><?php echo $Status; ?></label></td>
					</td>
                </tr>
				
				
                <tr>
                	<td colspan="2" style="text-align:center;">
                     <input type="submit" name="btnDelete" value="Delete" onClick="return confirm(' Are You Sure To Delete? ');"/>
					 <?php
					   if($Status=='New')
					   {
					   ?>
					 <input type="submit" name="btnAccept" value="Accept" />
					 <?php } ?>
					 
					 <button type="button" name="btnBack" onClick="window.location.href='AdminWarehouseList.php'">Back</button>
                    </td>
                </tr>
                   
           </table>
           </form>
         
  
  
    <?php
  include("../MasterPages/Footer.php");
  ?>
  
