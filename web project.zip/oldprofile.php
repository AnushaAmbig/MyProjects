<?php
  include("MasterPages/Header.php");
  ?>
  
  <h1>StarAgri</h1>
  
  
  <p>
StarAgri is focused on empowering farmers both small and large - so that they gain more from their harvests.We help farming communities protect their produce and reduce post harvest losses to increase food availability without placing additional burden on the environment. As agriculture moves up the global growth agenda, we are addressing one of the planets most pressing challenges today - food security with depleting resources.
</p>
<p>
Founded in 2006, StarAgri is one of Asias leading post harvest solutions company with global ambitions. With an integrated agri-solutions strategy across the post harvest needs of both producers and buyers, we leverage tie-ups with some of Indias leading financial institutions to hold commodities worth INR 75 billion across over 200 collateral management locations. Our unrivalled farmer reach, in-depth understanding of the agribusiness and appreciation of the challenges facing the countrys rural sector have enabled us to grow into one of Indias most preferred agribusiness service provider.
</p>
<p>
With a pan-India network of 800+ warehouses across 16 states and over 1.5 million tonnes of warehousing capacity, StarAgri caters to customers ranging from banks to international bulk commodity buyers, food, health & FMCG companies and commodity exchanges. We deliver integrated post harvest solutions including warehousing, collateral financing, procurement and value-added services to enhance efficiency across the entire food supply chain.
</p>
<p>
By creating a workplace that attracts the best professional talent, integrating risk management in agri-credit and practicing global standards of governance, StarAgri aims to be the most respected and inclusive agri-solutions company. Today, we have direct relationships with more than 100,000 farmers across India and aim to reach many more as we build global scale. Collaborating with more farmers in more places than ever before, we will together address the daunting challenge of food security for a growing world.

  </p>
  
  <?php
  include("MasterPages/Footer.php");
  ?>
  