  <?php
session_start();
$BookedBy=$_SESSION['UserID'];
?>
 
 <?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include_once "../DB/db.php";

$ID=$_REQUEST['ID'];

	$sql = "SELECT * FROM tblwarehouse where ID=$ID";
	
	$result=execute($sql);	
	
	if($row = $result->fetch_assoc())
 	{
		$BookedWarehouse=$row['Mobile'];
	}
?>


<?php


if (isset($_POST['btnSave']))
{
	$Product=$_POST['txtProduct'];
	$Quantity=$_POST['txtQuantity'];
	$From=$_POST['txtFrom'];
	$To=$_POST['txtTo'];
	$Remarks=$_POST['txtRemarks'];
	
	$BookedDate=date('Y-m-d');
	$From=date("Y-m-d", strtotime($From));
	$To=date("Y-m-d", strtotime($To));
	
	 $sql="INSERT INTO `tblbookings`(`BookedDate`, `Product`, `Quantity`, `FromDate`, `ToDate`, `Remarks`, `BookedBy`, `BookedWarehouse`, `Status`) VALUES ('$BookedDate','$Product','$Quantity','$From','$To','$Remarks','$BookedBy','$BookedWarehouse','New')";
	    	
	$res=execute($sql);	
		
	if($res)
	{
	
		echo "<script type='text/javascript'> alert('Warehouse owners will contact you for price details and process your orders.');</script>";
		echo "<meta http-equiv='refresh' content='0;url=FarmerWarehouseList.php'>";
	}
	else
	{
		echo "<script type='text/javascript'> alert('Action not processed');</script>";
	}
}
	
?>

 
 <?php
  include("../MasterPages/FarmerHeader.php");
  ?>
  
  <form id="frmadd" name="frmadd" method="post" action="">
           	<table id="bigtable">
			
				<tr>
            <td>
           Product
            </td>
            <td>
             <input type="text" name="txtProduct"/>
          </td>
		  
		  <td>
           Quantity
            </td>
            <td>
             <input type="text" name="txtQuantity"/>
          </td>
		</tr>
		
            <tr>
            <td>
           From
            </td>
            <td>
             <input type="text" name="txtFrom" id="txtFrom"/>
          </td>
		  
		  <td>
           To
            </td>
            <td>
             <input type="text" name="txtTo" id="txtTo"/>
          </td>
		</tr>
		
			<tr>
            <td>
           Remarks
            </td>
            <td>
            <textarea name="txtRemarks" style="height:100px;"></textarea>
          </td>
		  
		  <td colspan="2" style="text-align:center">
         <Input type="submit" name="btnSave" value="Save" onclick="return check(frmadd)"/>
		 
		   <button type="button" name="btnBack" onClick="window.location.href='FarmerWarehouseList.php'">Back</button>
          </td>
		</tr>
	
		
		</table>
		</form>
  
  
      <?php
  include("../MasterPages/Footer.php");
  ?>
  

<script language="javascript">
function check(f)
{
if (f.txtProduct.value=="")
{
alert("This Product Name field can not be empty");
f.txtProduct.focus();
return false ;
}
else if (f.txtQuantity.value.trim()=="")
{
alert("This Quantity field can not be empty");
f.txtQuantity.focus();
return false ;
}
else if (f.txtFrom.value.trim()=="")
{
alert("This From field can not be empty");
f.txtFrom.focus();
return false ;
}
else if (comparetodaydate(f.txtFrom)==true)
{
alert("This From Date should be greater than today date");
f.txtFrom.focus();
return false ;
}
else if (f.txtTo.value.trim()=="")
{
alert("This To field can not be empty");
f.txtTo.focus();
return false ;
}
else if (comparetodaydate(f.txtTo)==true)
{
alert("This To Date should be greater than today date");
f.txtTo.focus();
return false ;
}

else
return true;
}

</script>



 <script src="../js/Calendar/jquery.min.js" type="text/javascript"></script>
    <script src="../js/Calendar/jquery-ui.min.js" type="text/javascript"></script>
    <link href="../js/Calendar/jquery-ui.css" rel="Stylesheet" type="text/css" />
    <script type="text/javascript">
        $(function () {
            $('#txtFrom').datepicker({
                dateFormat: "dd-mm-yy",
                changeMonth: true,
                changeYear: true
            });
			
			
			 $('#txtTo').datepicker({
                dateFormat: "dd-mm-yy",
                changeMonth: true,
                changeYear: true
            });
        });
    </script>
	