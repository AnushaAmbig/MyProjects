 <?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include_once "../DB/db.php";

$ID=$_REQUEST['ID'];

	$sql = "SELECT * FROM tblwarehouse where ID=$ID";
	
	$result=execute($sql);	
	
	if($row = $result->fetch_assoc())
 	{
		$Mobile=$row['Mobile'];
	}
?>

<?php
if(isset($_REQUEST['cmbRate']))
{
		$sel3="select * from tblratings where Warehouse = '$Mobile'";
		$result=execute($sel3);	
		
		if ($result->num_rows > 0) 
		{
			if($row = $result->fetch_assoc())
 			{
				$rate = ($row["Ratings"] +  $_REQUEST['cmbRate'])/($row["FarmersRated"] + 1);
			}
			$FarmersRated=$row["FarmersRated"]+1;
			$sql="UPDATE `tblratings` SET `Ratings` = '".$rate."',`FarmersRated` = '".$FarmersRated."' WHERE `Warehouse` ='$Mobile'";
			
			$res=execute($sql);	
			
			if ($res) 
			{
				echo "<script type='text/javascript'> alert('Thanks for your Feebback');</script>";
				//echo "<meta http-equiv='refresh' content='0;url=FarmerWarehouseList.php'>";
			}
			else
			{
			 echo "<script type='text/javascript'> alert('Action is not processed.');</script>";
			 //echo "<meta http-equiv='refresh' content='0;url=FarmerWarehouseList.php'>";
			}
		
		}
		else
		{
			$rate = $_REQUEST['cmbRate'];
			$nos = 1;
			$sql="insert into tblratings(`Warehouse` ,`Ratings`,`FarmersRated` )
				  values('$Mobile','".$rate."','".$nos."')";
				  
			$res=execute($sql);	
			
			if ($res) 
			{
				echo "<script type='text/javascript'> alert('Thanks for your Feebback');</script>";
				//echo "<meta http-equiv='refresh' content='0;url=FarmerWarehouseList.php'>";
			}
			else
			{
			 echo "<script type='text/javascript'> alert('Action is not processed.');</script>";
			 //echo "<meta http-equiv='refresh' content='0;url=FarmerWarehouseList.php'>";
			}
		}
		
	
}

?>

 
 <?php
  include("../MasterPages/FarmerHeader.php");
  ?>
  
  <form id="frmaddratings" name="frmaddratings" method="post" action="">
           	<table id="logintable">
            <tr>
            <td>
            Rate
            </td>
            <td>
             <select name="cmbRate" onChange="check1()" class="select">
          <option value="">---Select Rating---</option>
          <option value="1">1 Star</option>
          <option value="2">2 Star</option>
          <option value="3">3 Star</option>
          <option value="4">4 Star</option>
          <option value="5">5 Star</option>
          <option value="6">6 Star</option>
          <option value="7">7 Star</option>
          <option value="8">8 Star</option>
          <option value="9">9 Star</option>
          <option value="10">10 Star</option>
          </select>		
          </td>
		</tr>
		</table>
		</form>
  
  
      <?php
  include("../MasterPages/Footer.php");
  ?>
  
  <script type="text/javascript">
function check1() {
     document.frmaddratings.submit()
}
</script>