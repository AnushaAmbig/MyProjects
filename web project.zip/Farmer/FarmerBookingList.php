  <?php
session_start();
$BookedBy=$_SESSION['UserID'];
?>
 
 
<?php
   
   include_once "../DB/db.php";

  include("../MasterPages/FarmerHeader.php");
  ?>
  
  
 <h1>Warehouse List</h1>

 
  <?php
			$sql = "SELECT b.ID,w.WarehouseName,b.BookedDate,b.Status FROM tblbookings b,tblwarehouse w where b.BookedBy='$BookedBy' and b.BookedWarehouse=w.Mobile";
	
			$result=execute($sql);	
	
			if ($result->num_rows > 0) 
			{

?>



	 <table id="fulltable">
     
     <tr>
	 <th>Warehouse Name</th>
     <th>Booked Date</th>
	 <th>Status</th>
      <th>View</th>
     </tr>
     
     <?php
while($row = $result->fetch_assoc()) 
  { ?>
     <tr>
      <td> <?php echo $row['WarehouseName']; ?></td>
	  <td> <?php $BookedDate=date('d-m-Y', strtotime($row['BookedDate'])); echo $BookedDate; ?></td>
      <td> <?php echo $row['Status']; ?></td>
   <td><a href="FarmerBookingsView.php?ID=<?php echo $row['ID']; ?>">View</a></td>
	</tr>
<?php
  }
?>
   </table>
   
  
    <?php
	}
	else
	{
	   echo "No Records Found";
	}

  include("../MasterPages/Footer.php");
  ?>
  
