<?php
   
   include_once "../DB/db.php";

  include("../MasterPages/FarmerHeader.php");
  ?>
  
  
 <h1>Warehouse List</h1>

 
  <?php
			$sql = "SELECT * FROM tblwarehouse";
	
			$result=execute($sql);	
	
			if ($result->num_rows > 0) 
			{

?>



	 <table id="fulltable">
     
     <tr>
	 <th>Warehouse Name</th>
     <th>City</th>
	 <th>Mobile</th>
      <th>View</th>
     </tr>
     
     <?php
while($row = $result->fetch_assoc()) 
  { ?>
     <tr>
      <td> <?php echo $row['WarehouseName']; ?></td>
	 <td> <?php echo $row['City']; ?></td>
      <td> <?php echo $row['Mobile']; ?></td>
   <td><a href="FarmerWarehouseView.php?ID=<?php echo $row['ID']; ?>">View</a></td>
	</tr>
<?php
  }
?>
   </table>
   
  
    <?php
	}
	else
	{
	   echo "No Records Found";
	}

  include("../MasterPages/Footer.php");
  ?>
  
  <script type="text/javascript">
function check1() {
     document.frmlist.submit()
}
</script>