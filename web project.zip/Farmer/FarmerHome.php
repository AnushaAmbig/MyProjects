 <?php
  include("../MasterPages/FarmerHeader.php");
  ?>
  
  <h1>Welcome for Farmer Login</h1>
  
  <ul>
  <li>Registered Farmer can view Warehouse and book warehouse.</li>
  <li>Farmer can change the password.</li>
  <li>Farmer can view the registered information.</li>
  </ul>
  
  
   <?php
  include("../MasterPages/Footer.php");
  ?>
  