<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include_once "../DB/db.php";

$ID=$_REQUEST['ID'];

	$sql = "SELECT * FROM tblwarehouse where ID=$ID";
	
	$result=execute($sql);	
	
	if($row = $result->fetch_assoc())
 	{
 		$ID=$row['ID'];
		$WarehouseName=$row['WarehouseName'];
		$Category=$row['Category'];
		$AddressLine1=$row['AddressLine1'];
		$AddressLine2=$row['AddressLine2'];
		$City=$row['City'];
		$Mobile=$row['Mobile'];
		$BuiltUpArea=$row['BuiltUpArea'];
		$Capacity=$row['Capacity'];
		$AboutWarehouse=$row['AboutWarehouse'];
		$Status=$row['Status'];
	}
?>


<?php
$sel2="select * from tblratings where Warehouse = '$Mobile'";
$result=execute($sel2);	
if ($result->num_rows > 0) 
{
	if($res2 = $result->fetch_assoc())
	{
	   $rat="<strong>".$res2['Ratings']."</strong> STARS out of <strong>10</strong> stars by ".$res2['FarmersRated']." Farmers";
	}
}
else
	$rat="No ratings";
?>
						
  <?php
  include("../MasterPages/FarmerHeader.php");
  ?>
  
  <h1>Warehouse Details Page</h1>
  
            
<form id="frmUsers" name="frmUsers" method="post" action="" enctype="multipart/form-data">
           	<table id="displaytable">
			 <tr>
                	<td colspan="4" style="text-align:center;">
					 <button type="button" name="btnBack" onClick="window.location.href='FarmerWarehouseList.php'">Back</button>
					 
					  
					   <button type="button" name="btnRating" onClick="window.location.href='FarmerPostRating.php?ID=<?php echo $ID; ?>'">Post Ratings</button>
					   
					   <button type="button" name="btnBook" onClick="window.location.href='FarmerWarehouseBooking.php?ID=<?php echo $ID; ?>'">Book</button>
                    </td>
                </tr>
				
				<tr>
                	<td style="width:20%;">Warehouse Name</td>
                    <td style="width:25%;"><?php echo $WarehouseName; ?></td>
                
					<td style="width:20%;">Category </td>
                    <td style="width:25%;"><?php echo $Category; ?></td>
                </tr>
				
                
				<tr>
					<td style="width:20%;">Address Line1 </td>
                    <td style="width:25%;"><?php echo $AddressLine1; ?></td>
               
                	<td>Address Line2 </td>
                    <td><?php echo $AddressLine2; ?></td>
                 </tr>
				
				<tr>
					<td>City</td>
					<td><?php echo $City; ?></td>
                
				  
                	<td>Mobile</td>
					<td><?php echo $Mobile; ?></td>
                </tr>
				
				<tr>
					<td>BuiltUp Area</td>
                    <td><?php echo $BuiltUpArea; ?></td>
               
                	<td>Capacity</td>
                    <td><?php echo $Capacity; ?></td>
                 </tr>
				
				<tr>
					<td>About Warehouse</td>
                    <td><?php echo $AboutWarehouse; ?></td>
                
                	<td>Ratings</td>
                    <td><?php echo $rat; ?></td>
                </tr>
				
				
               
                   
           </table>
           </form>
         
  
  
    <?php
  include("../MasterPages/Footer.php");
  ?>
  
