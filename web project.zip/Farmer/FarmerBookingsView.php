<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include_once "../DB/db.php";

$ID=$_REQUEST['ID'];


$sql = "SELECT * FROM tblbookings where ID=$ID";
	
	$result=execute($sql);	
	
	if($row = $result->fetch_assoc())
 	{
 		$ID=$row['ID'];
		$BookedDate=$row['BookedDate'];
		$Product=$row['Product'];
		$Quantity=$row['Quantity'];
		$FromDate=$row['FromDate'];
		$ToDate=$row['ToDate'];
		$Remarks=$row['Remarks'];
		$BookedBy=$row['BookedBy'];
		$BookedWarehouse=$row['BookedWarehouse'];
		$Status=$row['Status'];
	}
	
$BookedDate=date('d-m-Y', strtotime($row['BookedDate']));
$FromDate=date('d-m-Y', strtotime($row['FromDate']));
$ToDate=date('d-m-Y', strtotime($row['ToDate']));

	$sql = "SELECT * FROM tblwarehouse where Mobile='$BookedWarehouse'";
	
	$result=execute($sql);	
	
	if($row = $result->fetch_assoc())
 	{
		$WarehouseName=$row['WarehouseName'];
		$AddressLine1=$row['AddressLine1'];
		$AddressLine2=$row['AddressLine2'];
		$City=$row['City'];
		$Mobile=$row['Mobile'];
		$BuiltUpArea=$row['BuiltUpArea'];
		$Capacity=$row['Capacity'];
		$AboutWarehouse=$row['AboutWarehouse'];
	}
?>

		
<?php
$sel2="select * from tblratings where Warehouse = '$Mobile'";
$result=execute($sel2);	
if ($result->num_rows > 0) 
{
	if($res2 = $result->fetch_assoc())
	{
	   $rat="<strong>".$res2['Ratings']."</strong> STARS out of <strong>10</strong> stars by ".$res2['FarmersRated']." Farmers";
	}
}
else
	$rat="No ratings";
?>
							
  <?php
  include("../MasterPages/FarmerHeader.php");
  ?>
  
  <h1>Warehouse Details Page</h1>
  
            
<form id="frmUsers" name="frmUsers" method="post" action="" enctype="multipart/form-data">
           	<table id="displaytable">
			 <tr>
                	<td colspan="4" style="text-align:center;">
					 <button type="button" name="btnBack" onClick="window.location.href='FarmerBookingList.php'">Back</button>
					 
                    </td>
                </tr>
				
				<tr>
				<th colspan="4" style="text-align:center">
				Booking Details
				</th>
				</tr>
				
				<tr>
                	<td>Booked Date </td>
                    <td><?php echo $BookedDate; ?></td>
                
					<td>Product</td>
					<td><?php echo $Product; ?></td>
                </tr>
				
				
				<tr>
                	<td>Quantity </td>
                    <td><?php echo $Quantity; ?></td>
                
					<td>From Date</td>
					<td><?php echo $FromDate; ?></td>
                </tr>
				
					<tr>
                	<td>To Date </td>
                    <td><?php echo $ToDate; ?></td>
                
					
                </tr>
				<tr>
                	<td>Remarks </td>
                    <td><?php echo $Remarks; ?></td>
                </tr>
				
				
				
				<tr>
				<th colspan="4" style="text-align:center">
				Warehouse Details
				</th>
				</tr>
				
				<tr>
                	<td style="width:20%;">Warehouse Name</td>
                    <td style="width:25%;"><?php echo $WarehouseName; ?></td>
                
					<td style="width:20%;">Address Line1 </td>
                    <td style="width:25%;"><?php echo $AddressLine1; ?></td>
                </tr>
				
                	
				<tr>
                	<td>Address Line2 </td>
                    <td><?php echo $AddressLine2; ?></td>
                
					<td>City</td>
					<td><?php echo $City; ?></td>
                </tr>
				
				
				  <tr>
                	<td>Mobile</td>
					<td><?php echo $Mobile; ?></td>
                
					<td>BuiltUp Area</td>
                    <td><?php echo $BuiltUpArea; ?></td>
                </tr>
				
				<tr>
                	<td>Capacity</td>
                    <td><?php echo $Capacity; ?></td>
                
					<td>About Warehouse</td>
                    <td><?php echo $AboutWarehouse; ?></td>
                </tr>
				
				<tr>
                	<td>Ratings</td>
                    <td><?php echo $rat; ?></td>
                
					<td>About Warehouse</td>
                    <td><?php echo $AboutWarehouse; ?></td>
                </tr>
               
                   
           </table>
           </form>
         
  
  
    <?php
  include("../MasterPages/Footer.php");
  ?>
  
