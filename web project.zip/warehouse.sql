-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2018 at 02:43 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `warehouse`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblbookings`
--

CREATE TABLE `tblbookings` (
  `ID` int(11) NOT NULL,
  `BookedDate` date NOT NULL,
  `Product` varchar(100) NOT NULL,
  `Quantity` varchar(100) NOT NULL,
  `FromDate` date NOT NULL,
  `ToDate` date NOT NULL,
  `Remarks` varchar(500) NOT NULL,
  `BookedBy` varchar(20) NOT NULL,
  `BookedWarehouse` varchar(15) NOT NULL,
  `Status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbookings`
--

INSERT INTO `tblbookings` (`ID`, `BookedDate`, `Product`, `Quantity`, `FromDate`, `ToDate`, `Remarks`, `BookedBy`, `BookedWarehouse`, `Status`) VALUES
(1, '2018-04-02', 'paddy', '2 ton', '2018-04-30', '2018-07-31', 'hhh', '7019603517', '9738589297', 'Processed');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `ID` int(11) NOT NULL,
  `Category` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`ID`, `Category`) VALUES
(2, 'Cold Storage'),
(3, 'Fruit Storage'),
(4, 'Food Storage'),
(1, 'Hot Storage');

-- --------------------------------------------------------

--
-- Table structure for table `tblcity`
--

CREATE TABLE `tblcity` (
  `ID` int(11) NOT NULL,
  `City` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcity`
--

INSERT INTO `tblcity` (`ID`, `City`) VALUES
(1, 'Bangalore'),
(2, 'Davangere'),
(3, 'Harihar'),
(4, 'Hubli'),
(5, 'Mangalore'),
(6, 'Mysore'),
(7, 'Karwar'),
(8, 'Bellary');

-- --------------------------------------------------------

--
-- Table structure for table `tblformers`
--

CREATE TABLE `tblformers` (
  `ID` int(11) NOT NULL,
  `FormerName` varchar(100) NOT NULL,
  `AddressLine1` varchar(100) NOT NULL,
  `AddressLine2` varchar(100) NOT NULL,
  `City` varchar(100) NOT NULL,
  `Mobile` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblformers`
--

INSERT INTO `tblformers` (`ID`, `FormerName`, `AddressLine1`, `AddressLine2`, `City`, `Mobile`) VALUES
(1, 'Praveen Kumar K', 'Fourth Cross', 'Vidya Nagar', 'Davangere', '8722864794'),
(2, 'Manoj S', 'Vidya nagar', 'Third Cross', 'Davangere', '7019603517');

-- --------------------------------------------------------

--
-- Table structure for table `tbllogin`
--

CREATE TABLE `tbllogin` (
  `ID` int(11) NOT NULL,
  `UserID` varchar(100) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `UserType` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbllogin`
--

INSERT INTO `tbllogin` (`ID`, `UserID`, `Password`, `UserType`) VALUES
(1, 'admin', 'admin', 'Admin'),
(2, '8722864794', '123456', 'Former'),
(4, '9741726679', '123456', 'Warehouse'),
(5, '9738589297', 'pZgFT', 'Warehouse'),
(6, '7019603517', '123456', 'Former');

-- --------------------------------------------------------

--
-- Table structure for table `tblratings`
--

CREATE TABLE `tblratings` (
  `ID` int(11) NOT NULL,
  `Warehouse` varchar(15) NOT NULL,
  `Ratings` int(11) NOT NULL,
  `FarmersRated` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblratings`
--

INSERT INTO `tblratings` (`ID`, `Warehouse`, `Ratings`, `FarmersRated`) VALUES
(2, '9741726679', 9, 2),
(3, '9738589297', 7, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tblwarehouse`
--

CREATE TABLE `tblwarehouse` (
  `ID` int(11) NOT NULL,
  `WarehouseName` varchar(100) NOT NULL,
  `Category` varchar(100) NOT NULL,
  `AddressLine1` varchar(100) NOT NULL,
  `AddressLine2` varchar(100) NOT NULL,
  `City` varchar(100) NOT NULL,
  `Mobile` varchar(20) NOT NULL,
  `BuiltUpArea` varchar(100) NOT NULL,
  `Capacity` varchar(100) NOT NULL,
  `AboutWarehouse` varchar(500) NOT NULL,
  `Status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblwarehouse`
--

INSERT INTO `tblwarehouse` (`ID`, `WarehouseName`, `Category`, `AddressLine1`, `AddressLine2`, `City`, `Mobile`, `BuiltUpArea`, `Capacity`, `AboutWarehouse`, `Status`) VALUES
(6, 'Star India', '', 'Third Cross', 'Vidya Nagar', 'Davangere', '9741726679', 'Two Acres', '100 tonns', 'This is good warehouse. Nice for storage', 'Accepted'),
(7, 'Saptha Giri', '', 'Vidya nagar', 'Third Cross', 'Davangere', '9738589297', 'gtt', 'gty', 'gyyy', 'Accepted'),
(8, 'Saptha Giri', 'Cold Storage', 'Vidya nagar', 'Third Cross', 'Davangere', '8951500308', 'gtt', 'gty', 'dsa', 'New');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblbookings`
--
ALTER TABLE `tblbookings`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblcity`
--
ALTER TABLE `tblcity`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblformers`
--
ALTER TABLE `tblformers`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbllogin`
--
ALTER TABLE `tbllogin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblratings`
--
ALTER TABLE `tblratings`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblwarehouse`
--
ALTER TABLE `tblwarehouse`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblbookings`
--
ALTER TABLE `tblbookings`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblcity`
--
ALTER TABLE `tblcity`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblformers`
--
ALTER TABLE `tblformers`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbllogin`
--
ALTER TABLE `tbllogin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblratings`
--
ALTER TABLE `tblratings`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblwarehouse`
--
ALTER TABLE `tblwarehouse`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
