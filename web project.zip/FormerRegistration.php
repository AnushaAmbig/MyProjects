   <?php  
  include_once "DB/db.php";
  ?>
  
   <?php
  if(isset($_REQUEST['btnSave']))
  {
	$FormerName=$_POST['txtFormerName'];
	$AddressLine1=$_POST['txtAddressLine1'];
	$AddressLine2=$_POST['txtAddressLine2'];
	$City=$_POST['cmbCity'];
	$Mobile=$_POST['txtMobile'];
	$Password=$_POST['txtPassword'];
					
	$sql = "SELECT * FROM tbllogin WHERE UserID = '$Mobile'";	
	$ress=execute($sql);	
	if ($ress->num_rows > 0) 
	{
		echo "<script type='text/javascript'> alert('This Mobile Number is already Registered.');</script>";
	}
	else
	{

		$sql="INSERT INTO `tblformers`(`FormerName`, `AddressLine1`, `AddressLine2`, `City`, `Mobile`) VALUES ('$FormerName','$AddressLine1','$AddressLine2','$City','$Mobile')";
		$res=execute($sql);	
		
		$insert="INSERT INTO `tbllogin` (`UserID`, `Password`, `UserType`) VALUES ('$Mobile','$Password', 'Former')";
		$res=execute($insert);
		$mobileno=$Mobile;
		
		if($res)
		{
			echo "<script type='text/javascript'> alert('Registered Successfully');</script>";
			echo "<meta http-equiv='refresh' content='0;url=Login.php'>";
		}
		else
		{
			echo "<script type='text/javascript'> alert('Action is not processed');</script>";
		}
	}
}
?>

  <?php  
  
  include("MasterPages/Header.php");
  ?>
  
  <h1>Register Here</h1>

                <form id="frmadd" name="frmadd" method="post" action="">
           	<table id="logintable">
            					
				<tr>
                	<td>Farmer Name</td>
					<td><input type="text" name="txtFormerName" maxlength="100"/></td>
                </tr>
				
				<tr>
                	<td>Address Line1</td>
					<td><input type="text" name="txtAddressLine1" maxlength="100"/></td>
                </tr>
				
				<tr>
                	<td>Address Line2</td>
					<td><input type="text" name="txtAddressLine2" maxlength="100"/></td>
                </tr>

				<tr>
            <td>City</td>
            <td>
    			 <select name="cmbCity"  class="select">
        		    <option value="0">Select</option>
      				<?php
						 $sql = "SELECT DISTINCT(City) FROM tblcity";
						$res=execute($sql);	
						
					   	while($result = $res->fetch_assoc())
        				{
	  			      ?>
				            <option value = "<?php echo $result['City']?>"><?php echo $result['City'] ?></option>                           
        				<?php
							}
						?>
                        </select>
                        </td>
            </tr>
			
				<tr>
                	<td>Mobile</td>
					<td><input type="text" name="txtMobile" onKeyPress="return numbersonly(event, false)" maxlength="10" required/></td>
					
                </tr>
		
		<tr>
            	<td>Password</td>
		   		<td><input type="text" name="txtPassword" maxlength="8" required /></td>
     			</tr>
				
                <tr>
                	<td colspan="2" style="text-align:center;">
                    <input type="submit" name="btnSave" onClick="return check(frmadd)" value="Register" />
                    <button type="button" name="btncancel" onClick="window.location.href='Login.php'">Cancel</button>
   	
                    </td>
                </tr>
           </table>
           </form>
  
         			<?php
  include("MasterPages/Footer.php");
  ?>
  
  
  <script language="javascript">
function check(f)
{
if (f.txtFormerName.value=="")
{
alert("This Former Name field can not be empty");
f.txtFormerName.focus();
return false ;
}
else if (f.txtAddressLine1.value.trim()=="")
{
alert("This AddressLine1 field can not be empty");
f.txtAddressLine1.focus();
return false ;
}
else if (f.txtCity.value.trim()=="")
{
alert("This City field can not be empty");
f.txtCity.focus();
return false ;
}
else if (f.txtMobile.value=="" || checkmobile(f.txtMobile)==false)
{
   alert("This Phone No field can not be Empty");
   f.txtMobile.focus();
   return false;
}
else if(f.txtPassword.value=="" || f.txtPassword.value.length<6)
{
	alert("This password should be greater than 6 characters");
	f.txtPassword.focus();
	return false ;
}
else
return true;
}

</script>
