<?php

echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Agricultural Ware House Portal</title>
<link href="../css/styles.css" rel="stylesheet" type="text/css" />
<link href="../css/control.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../js/validation.js"></script>
</head>
<body>
<div id="mainbg">
<div id="main">
<!-- header begins -->
<div id="logo"><a href="#">Agricultural Ware House Portal</a>
		<h2><a href="#">Find Ware House</a></h2>
	</div>

	<div id="buttons">
		<ul>
			<li class="first"><a href="AdminBookingsList.php"  title="">Bookings</a></li>
			<li><a href="AdminFormerList.php" title="">Farmers</a></li>
			<li><a href="AdminWarehouseList.php" title="">Warehouse</a></li>
			<li><a href="AdminCategoryList.php" title="">Categories</a></li>
			<li><a href="AdminCityList.php" title="">Cities</a></li>
			<li><a href="../Logout.php" title="">Logout</a></li>
		</ul>
</div>
<!-- header ends -->
<!-- content begins -->
<div id="content_bg">';

?>
