<?php

echo '</div>
<!-- content ends -->
<!-- footer begins -->
<div id="footer">
  <p>Copyright  2019. Designed by | SJBIT College Students.</p>
</div>
<!-- footer ends -->
</div>
</div>
</body>
</html>
';

?>