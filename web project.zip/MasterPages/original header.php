<?php

echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Agricultural Ware House Portal</title>
<link href="css/normalize.css" rel="stylesheet" type="text/css" />
<link href="css/styles.css" rel="stylesheet" type="text/css" />
<link href="css/control.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/validation.js"></script>
</head>
<body>
<div id="mainbg">
<div id="main">
<!-- header begins -->

<div id="buttons">
		<h2>
			<a href="/" class="logo-text">Agricultural Ware House Portal</a>
			<span class="logo-desc">Find Ware House</span>
		</h2>
	<ul>
		<li class="first"><a href="Index.php"  title="">Home</a></li>
		<li><a href="OurProfile.php" title="">Our Profile</a></li>
		<li><a href="MeetUs.php" title="">Meet Us</a></li>
		<li><a href="Login.php" title="">Login</a></li>
	</ul>
</div>
<div id="header"></div>

<!-- header ends -->
<!-- content begins -->
<div id="content_bg">';

?>
