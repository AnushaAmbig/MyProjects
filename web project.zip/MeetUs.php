
   <?php
  include("MasterPages/Header.php");
  ?>
  
  <h1>If You have any Queries Then Contact Us At</h1>
  
  
  <pre>
<center>
<h4> Aparna Bhatt </h4>
 Email: <a href="mailto:aparnabhatt10@gmail.com">aparnabhatt10@gmail.com</a>
 Mob: <a href="callto:9972414510">+919972414510</a>
 <h4> Anusha Ambig </h4>
 Email: <a href="mailto:anushaambig99@gmail.com">anushaambig99@gmail.com</a>
 Mob: <a href="callto:7892960398">+917892960398</a>
</center>
</pre>

  
  <?php
  include("MasterPages/Footer.php");
  ?>
  