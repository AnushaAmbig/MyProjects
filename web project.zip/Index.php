
   <?php
  include("MasterPages/Header.php");
  ?>
  
  <h1>Agricultural Ware House Portal</h1>
  
  
  <p>
  Indian economy is an agrarian economy with over 70% of the population engaged in activities related to agriculture. Indian food grain production has grown at an average rate of 1.20% over a period from 1994-95 with production of 192 million metric tonne (MMT) to an all time record output of 232 MMT in 2010-11 (15 years) and with the expectation of good monsoon in FY12 the uptrend is likely to continue. A major part of the food grain production consists of rice at about 94 MMT (41%) and wheat at about 82 MMT (35%). Further, production of Rabi and Kharif crops is now almost equal on account of growth in Rabi crop due to increased production of wheat, rice, cereals and pulses. All these taken together have drastically increased the need for storage capacity in India..
  </p>
  
  <p>
  Agricultural Warehouse Portal provides state-of-the-art temperature controlled storage through an integrated and modern pan-India warehousing network to maximize efficiency and reduce post harvest losses. Through the development of large-scale owned warehouses with modernized silo storage and handling solutions, we aim to significantly maximize harvest produce with high-quality storage, protection from pest infestation and pilferage to increase agricultural income. With a growing network of 800+ warehouses across 16 Indian states and over 1.5 million tonnes of warehousing capacity, Agricultural Warehouse Portal is a leading player in the Indian agri-warehousing market.
  </p>
  
  <?php
  include("MasterPages/Footer.php");
  ?>
  